import React, { useEffect, useState } from "react";

const API_KEY = "YOUR_API_KEY";

function App() {
  const [city, setCity] = useState("Mumbai");
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState("");

  const fetchWeather = async () => {
    try {
      setError("");
      const res = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`
      );
      const data = await res.json();

      if (data.cod !== 200) {
        setError("City Not Found");
        return;
      }
      setWeather(data);
    } catch {
      setError("Network Error");
    }
  };

  useEffect(() => {
    fetchWeather();
  }, []);

  return (
    <div className="container">
      <h1>Weather App</h1>
      <input type="text" value={city} onChange={e => setCity(e.target.value)} placeholder="Enter city" />
      <button onClick={fetchWeather}>Search</button>
      {error && <p className="error">{error}</p>}
      {weather && (
        <div className="box">
          <h2>{weather.name}</h2>
          <p>{weather.weather[0].description}</p>
          <h3>{weather.main.temp}°C</h3>
        </div>
      )}
    </div>
  );
}

export default App;
