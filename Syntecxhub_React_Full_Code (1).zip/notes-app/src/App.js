import React, { useState, useEffect, useRef } from "react";

function App() {
  const [notes, setNotes] = useState([]);
  const inputRef = useRef();

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("notes"));
    if (saved) setNotes(saved);
  }, []);

  useEffect(() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);

  const addNote = () => {
    const text = inputRef.current.value;
    if (!text) return;

    setNotes([...notes, { id: Date.now(), text }]);
    inputRef.current.value = "";
    inputRef.current.focus();
  };

  const deleteNote = id => {
    setNotes(notes.filter(n => n.id !== id));
  };

  return (
    <div className="container">
      <h1>Notes App</h1>
      <input ref={inputRef} type="text" placeholder="Write a note..." />
      <button onClick={addNote}>Add Note</button>
      <ul>
        {notes.map(n => (
          <li key={n.id}>
            {n.text}
            <button onClick={() => deleteNote(n.id)}>X</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
