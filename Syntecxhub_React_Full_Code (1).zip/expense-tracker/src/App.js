import React, { useState, useEffect, useMemo, useCallback } from "react";
import ExpenseForm from "./ExpenseForm";
import ExpenseList from "./ExpenseList";

function App() {
  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts?_limit=5")
      .then(res => res.json())
      .then(data => {
        const formatted = data.map(item => ({
          id: item.id,
          title: item.title,
          amount: Math.floor(Math.random() * 500) + 1
        }));
        setExpenses(formatted);
      });
  }, []);

  const addExpense = useCallback(expense => {
    setExpenses(prev => [...prev, expense]);
  }, []);

  const totalAmount = useMemo(() => {
    return expenses.reduce((sum, exp) => sum + exp.amount, 0);
  }, [expenses]);

  return (
    <div className="container">
      <h1>Expense Tracker</h1>
      <h3>Total: ₹{totalAmount}</h3>
      <ExpenseForm onAdd={addExpense} />
      <ExpenseList expenses={expenses} />
    </div>
  );
}

export default App;
