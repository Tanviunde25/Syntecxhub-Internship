import React, { useState, useRef } from "react";

function ExpenseForm({ onAdd }) {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const inputRef = useRef(null);

  const handleSubmit = e => {
    e.preventDefault();
    onAdd({
      id: Date.now(),
      title,
      amount: Number(amount)
    });
    setTitle("");
    setAmount("");
    inputRef.current.focus();
  };

  return (
    <form className="exp-form" onSubmit={handleSubmit}>
      <input ref={inputRef} type="text" placeholder="Expense Title" value={title}
        onChange={e => setTitle(e.target.value)} required />
      <input type="number" placeholder="Amount" value={amount}
        onChange={e => setAmount(e.target.value)} required />
      <button>Add Expense</button>
    </form>
  );
}

export default ExpenseForm;
