import React from "react";

function ExpenseList({ expenses }) {
  return (
    <ul className="exp-list">
      {expenses.map(exp => (
        <li key={exp.id}>
          <span>{exp.title}</span>
          <strong>₹{exp.amount}</strong>
        </li>
      ))}
    </ul>
  );
}

export default ExpenseList;
